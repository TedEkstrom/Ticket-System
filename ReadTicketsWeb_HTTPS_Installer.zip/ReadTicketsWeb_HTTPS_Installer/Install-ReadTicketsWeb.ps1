[CmdletBinding()]
param(
    [Parameter(Position=0)]
    [string]$ZipPath = (Join-Path $PSScriptRoot 'ReadTicketsWeb.zip'),
    [string]$InstallPath = (Join-Path ([Environment]::GetEnvironmentVariable('ProgramFiles(x86)')) 'ReadTicketsWeb'),
    [int]$Port = 8443,
    # 0.0.0.0 = svara på alla namn och adresser. En specifik IP/ett specifikt namn ger 503 för allt annat.
    [string]$Bind = '0.0.0.0',
    [string]$TicketPath = '',
    # Extra DNS-namn som klienterna använder för att nå servern (t.ex. ett alias som tickets.firma.se).
    [string[]]$DnsName = @(),
    # Skapa certifikatet på nytt även om det befintliga verkar fungera.
    [switch]$NewCertificate,
    [switch]$NoStart
)

$ErrorActionPreference = 'Stop'

function Assert-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Installationen måste köras som administratör. Högerklicka på PowerShell och välj "Kör som administratör".'
    }
}

# Alla IPv4-adresser som klienter kan tänkas använda för att nå servern.
function Get-LocalIPv4 {
    try {
        $addresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
            Select-Object -ExpandProperty IPAddress
        return @($addresses | Select-Object -Unique)
    } catch {
        return @()
    }
}

function Get-RequiredCertificateNames {
    $computer = $env:COMPUTERNAME
    $names = @('localhost', $computer)
    if ($env:USERDNSDOMAIN) { $names += "$computer.$($env:USERDNSDOMAIN)".ToLowerInvariant() }
    foreach ($n in $DnsName) { if (-not [string]::IsNullOrWhiteSpace($n)) { $names += $n.Trim() } }
    return @{ Dns = @($names | Select-Object -Unique); Ip = @(Get-LocalIPv4) }
}

# Kontrollerar att ett befintligt certifikat täcker alla namn och IP-adresser som behövs.
# Jämför bara själva värdena, eftersom Format() ger lokaliserade etiketter.
function Test-CertificateCoversNames {
    param($Certificate, $Required)
    $ext = $Certificate.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' } | Select-Object -First 1
    if (-not $ext) { return $false }
    $text = $ext.Format($false)
    foreach ($value in @($Required.Dns) + @($Required.Ip)) {
        if ($text -notmatch [regex]::Escape($value)) { return $false }
    }
    return $true
}

function New-ReadTicketsCertificate {
    $computer = $env:COMPUTERNAME
    $required = Get-RequiredCertificateNames

    $existing = Get-ChildItem Cert:\LocalMachine\My |
        Where-Object { $_.FriendlyName -eq 'ReadTickets Web HTTPS' -and $_.HasPrivateKey } |
        Sort-Object NotAfter -Descending |
        Select-Object -First 1

    if (-not $NewCertificate -and $existing -and $existing.NotAfter -gt (Get-Date).AddDays(30) -and (Test-CertificateCoversNames $existing $required)) {
        $cert = $existing
        Write-Host "Använder befintligt certifikat $($cert.Thumbprint)." -ForegroundColor DarkGray
    } else {
        $sanParts = @()
        foreach ($d in $required.Dns) { $sanParts += "DNS=$d" }
        foreach ($i in $required.Ip)  { $sanParts += "IPAddress=$i" }
        $san = $sanParts -join '&'

        $cert = New-SelfSignedCertificate `
            -Subject "CN=$computer" `
            -CertStoreLocation 'Cert:\LocalMachine\My' `
            -FriendlyName 'ReadTickets Web HTTPS' `
            -NotAfter (Get-Date).AddYears(5) `
            -KeyAlgorithm RSA `
            -KeyLength 2048 `
            -HashAlgorithm SHA256 `
            -KeyUsage DigitalSignature,KeyEncipherment `
            -TextExtension @("2.5.29.17={text}$san", "2.5.29.37={text}1.3.6.1.5.5.7.3.1")
        Write-Host "Nytt certifikat skapat: $($cert.Thumbprint)" -ForegroundColor DarkGray
        Write-Host "  Namn/adresser: $($required.Dns -join ', ') $($required.Ip -join ', ')" -ForegroundColor DarkGray
    }

    # Lita på certifikatet på denna dator. Andra datorer måste importera .cer-filen (se slutet av utskriften).
    $root = Get-ChildItem Cert:\LocalMachine\Root | Where-Object Thumbprint -eq $cert.Thumbprint
    if (-not $root) {
        $rootStore = New-Object System.Security.Cryptography.X509Certificates.X509Store('Root','LocalMachine')
        $rootStore.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
        try { $rootStore.Add($cert) } finally { $rootStore.Close() }
    }

    if (-not $cert.HasPrivateKey) { throw "HTTPS-certifikatet saknar privat nyckel." }
    return $cert
}

function Set-HttpsBinding {
    param([System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate, [int]$Port)

    & netsh http delete sslcert ipport="0.0.0.0:$Port" 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { $global:LASTEXITCODE = 0 }

    $appId = '{B9F0C1A7-8A14-4B4C-9A7D-3B8E5A4F2C11}'
    $thumb = ($Certificate.Thumbprint -replace '\s','').ToUpperInvariant()
    $sslArgs = @(
        'http', 'add', 'sslcert',
        "ipport=0.0.0.0:$Port",
        "certhash=$thumb",
        "appid=$appId",
        'certstorename=MY'
    )
    & netsh @sslArgs
    if ($LASTEXITCODE -ne 0) {
        throw "Kunde inte skapa HTTPS-bindningen för port $Port. Kontrollera att certifikatet finns i LocalMachine\My och har privat nyckel."
    }

    # Servern körs av den som startar den (utan administratörsrättigheter) och behöver därför en URL ACL.
    $user = "$env:USERDOMAIN\$env:USERNAME"
    & netsh http delete urlacl "url=https://+:$Port/" 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { $global:LASTEXITCODE = 0 }
    & netsh http add urlacl "url=https://+:$Port/" "user=$user"
    if ($LASTEXITCODE -ne 0) { throw "Kunde inte skapa URL ACL för https://+:$Port/." }
}

function Set-FirewallRule {
    param([int]$Port)
    $name = 'ReadTickets Web HTTPS'
    if (Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue) {
        # Uppdatera även porten om den har ändrats sedan förra installationen.
        Get-NetFirewallRule -DisplayName $name | Get-NetFirewallPortFilter | Set-NetFirewallPortFilter -LocalPort $Port
        Set-NetFirewallRule -DisplayName $name -Enabled True -Action Allow -Profile Any
    } else {
        New-NetFirewallRule -DisplayName $name -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Any | Out-Null
    }
}

# Skriver server.json (Bind, Port, Protocol, CertificateThumbprint, TicketPath) bredvid owners.json.
function Ensure-ServerConfig {
    param([string]$ProfilePath, [int]$Port, [string]$Thumbprint)
    $dir = Join-Path $ProfilePath 'Readtickets'
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $file = Join-Path $dir 'server.json'
    $legacyFile = Join-Path $dir 'config.json'   # gammal gemensam config från tidigare version

    $cfg = [ordered]@{
        Bind                  = $Bind
        Port                  = $Port
        Protocol              = 'https'
        CertificateThumbprint = $Thumbprint
        TicketPath            = ''
    }

    # Behåll TicketPath från tidigare konfiguration (Bind sätts alltid av -Bind). server.json går före gamla config.json.
    foreach ($source in @($legacyFile, $file)) {
        if (-not (Test-Path -LiteralPath $source)) { continue }
        try { $old = Get-Content -LiteralPath $source -Raw -Encoding UTF8 | ConvertFrom-Json } catch { continue }
        foreach ($k in @('TicketPath')) {
            if (($old.PSObject.Properties.Name -contains $k) -and -not [string]::IsNullOrWhiteSpace([string]$old.$k)) {
                $cfg[$k] = [string]$old.$k
            }
        }
    }

    if ([string]::IsNullOrWhiteSpace($cfg.TicketPath)) {
        $defaultTicketPath = Join-Path $dir 'tickets'
        if (-not [string]::IsNullOrWhiteSpace($TicketPath)) {
            $cfg.TicketPath = $TicketPath
        } else {
            $answer = Read-Host "Ange sökväg till ticket-mappen (Enter = $defaultTicketPath)"
            if ([string]::IsNullOrWhiteSpace($answer)) { $answer = $defaultTicketPath }
            $cfg.TicketPath = $answer
        }
    } elseif (-not [string]::IsNullOrWhiteSpace($TicketPath)) {
        $cfg.TicketPath = $TicketPath   # uttryckligt -TicketPath vinner
    }

    ([pscustomobject]$cfg) | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $file -Encoding UTF8
    return $file
}

# Stoppar en server som körs från installationsmappen så att filerna kan ersättas.
function Stop-RunningServer {
    param([string]$InstallPath)
    try {
        $target = Join-Path $InstallPath 'server.ps1'
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
            Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf($target, [StringComparison]::OrdinalIgnoreCase) -ge 0 } |
            ForEach-Object {
                Write-Host "Stoppar körande ReadTickets-server (PID $($_.ProcessId))..." -ForegroundColor Yellow
                Stop-Process -Id $_.ProcessId -Force
            }
        Start-Sleep -Milliseconds 500
    } catch {}
}

Assert-Administrator

if (-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) {
    throw "ZIP-filen hittades inte: $ZipPath"
}

Write-Host 'Installerar ReadTickets Web...' -ForegroundColor Cyan
Write-Host "ZIP: $ZipPath"
Write-Host "Installation: $InstallPath"

# Packa upp till en tillfällig mapp först, så att en misslyckad uppackning inte raderar befintlig installation.
$temp = Join-Path ([IO.Path]::GetTempPath()) ("ReadTicketsWeb_" + [Guid]::NewGuid().ToString('N'))
try {
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $temp -Force

    # ZIP-filen kan ha en eller flera toppmappar. Hitta mappen som innehåller server.ps1.
    $serverScript = Get-ChildItem -LiteralPath $temp -Filter 'server.ps1' -Recurse -File | Select-Object -First 1
    if (-not $serverScript) { throw 'server.ps1 hittades inte i ZIP-filen.' }
    $sourceDir = $serverScript.DirectoryName

    Stop-RunningServer -InstallPath $InstallPath

    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    Get-ChildItem -LiteralPath $InstallPath -Force | Remove-Item -Recurse -Force
    Copy-Item -Path (Join-Path $sourceDir '*') -Destination $InstallPath -Recurse -Force
} finally {
    if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
}

$cert = New-ReadTicketsCertificate
Set-HttpsBinding -Certificate $cert -Port $Port
Set-FirewallRule -Port $Port

# Exportera certifikatets publika del (utan privat nyckel) så att andra datorer kan lita på det.
$cerPath = Join-Path $InstallPath 'www\ReadTicketsWeb.cer'
New-Item -ItemType Directory -Path (Split-Path $cerPath) -Force | Out-Null
Export-Certificate -Cert $cert -FilePath $cerPath -Type CERT -Force | Out-Null

$profilePath = $env:USERPROFILE
$serverFile = Ensure-ServerConfig -ProfilePath $profilePath -Port $Port -Thumbprint $cert.Thumbprint

# Startmenygenväg.
$startMenu = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\ReadTickets'
New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
$shortcutPath = Join-Path $startMenu 'ReadTickets Web.lnk'
$ws = New-Object -ComObject WScript.Shell
$shortcut = $ws.CreateShortcut($shortcutPath)
$shortcut.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -NoExit -File `"$InstallPath\server.ps1`""
$shortcut.WorkingDirectory = $InstallPath
$shortcut.Description = 'Starta ReadTickets Web'
$shortcut.Save()

if (-not $NoStart) {
    # Sökvägen (Program Files (x86)) innehåller mellanslag och måste citeras. -NoExit håller fönstret öppet så att fel syns.
    $serverArgs = "-NoProfile -ExecutionPolicy Bypass -NoExit -File `"$InstallPath\server.ps1`""
    Start-Process powershell.exe -ArgumentList $serverArgs -WorkingDirectory $InstallPath
}

$computer = $env:COMPUTERNAME
Write-Host ''
Write-Host 'Installation klar.' -ForegroundColor Green
Write-Host "URL: https://$computer`:$Port/" -ForegroundColor Green
foreach ($ip in @(Get-LocalIPv4)) { Write-Host "IP:  https://$ip`:$Port/" -ForegroundColor Green }
Write-Host ''
Write-Host 'Andra datorer:' -ForegroundColor Cyan
Write-Host "  Certifikatet är självsignerat. För att slippa certifikatvarning, kopiera"
Write-Host "  $cerPath"
Write-Host "  till klientdatorn och kör som administratör:"
Write-Host "    Import-Certificate -FilePath .\ReadTicketsWeb.cer -CertStoreLocation Cert:\LocalMachine\Root" -ForegroundColor Yellow
Write-Host "  (Filen kan också hämtas från https://$computer`:$Port/ReadTicketsWeb.cer)"
Write-Host "  Klienter måste använda ett namn/en IP som finns i certifikatet. Lägg till fler med -DnsName och -NewCertificate."
Write-Host ''
Write-Host "Certifikat: $($cert.Thumbprint)" -ForegroundColor DarkGray
Write-Host "Installation: $InstallPath" -ForegroundColor DarkGray
Write-Host "Serverinställningar: $serverFile" -ForegroundColor DarkGray
Write-Host "Profil: $profilePath\Readtickets" -ForegroundColor DarkGray
