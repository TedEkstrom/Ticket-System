const state={config:null,tickets:[],selected:null};

const $=id=>document.getElementById(id);
async function api(path,options={}){
  const r=await fetch(path,{headers:{"Content-Type":"application/json"},...options});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||`HTTP ${r.status}`);
  return data;
}
let authTimer=null;
function showAuthScreen(setup=false,error=""){
  $("appShell").classList.add("hidden");
  $("authScreen").classList.remove("hidden");
  const title=setup?"Skapa första användaren":"Logga in";
  const intro=setup?"Skapa det första administratörskontot.":"Logga in för att använda ReadTickets.";
  $("authCard").innerHTML=`<div class="brand-login">ReadTickets</div><h1>${title}</h1><p class="muted">${intro}</p>
    <div class="error" id="authError">${esc(error)}</div>
    <div class="field"><label>Användarnamn</label><input id="authUser" autocomplete="username"></div>
    <div class="field"><label>Lösenord</label><input id="authPassword" type="password" autocomplete="current-password"></div>
    ${setup?'<div class="field"><label>Bekräfta lösenord</label><input id="authPassword2" type="password" autocomplete="new-password"></div>':''}
    <button id="authSubmit">${setup?"Skapa användare":"Logga in"}</button>
    ${setup?'<div class="hint">Lösenordet lagras inte i klartext utan som PBKDF2-hash.</div>':''}`;
  $("authSubmit").onclick=async()=>{
    const username=$("authUser").value.trim();
    const password=$("authPassword").value;
    if(!username){$("authError").textContent="Fyll i användarnamn.";return;}
    if(!password){$("authError").textContent="Fyll i lösenord.";return;}
    if(setup && password!==$("authPassword2").value){$("authError").textContent="Lösenorden matchar inte.";return;}
    try{
      if(setup){
        await api("/api/auth/setup",{method:"POST",body:JSON.stringify({username,password})});
        await login(username,password);
      }else{
        await login(username,password);
      }
    }catch(e){$("authError").textContent=e.message}
  };
  $("authPassword").onkeydown=e=>{if(e.key==="Enter")$("authSubmit").click()};
}
function showPasswordSetup(username,error=""){
  $("appShell").classList.add("hidden");
  $("authScreen").classList.remove("hidden");
  $("authCard").innerHTML=`<div class="brand-login">ReadTickets</div><h1>Skapa lösenord</h1><p class="muted">Användaren <b>${esc(username)}</b> finns i owners.json men saknar lösenord.</p>
    <div class="error" id="authError">${esc(error)}</div>
    <div class="field"><label>Nytt lösenord</label><input id="newPassword" type="password" autocomplete="new-password"></div>
    <div class="field"><label>Bekräfta lösenord</label><input id="newPassword2" type="password" autocomplete="new-password"></div>
    <button id="setPasswordBtn">Spara lösenord</button>`;
  $("setPasswordBtn").onclick=async()=>{
    const password=$("newPassword").value;
    if(!password){$("authError").textContent="Fyll i lösenord.";return;}
    if(password!==$("newPassword2").value){$("authError").textContent="Lösenorden matchar inte.";return;}
    try{
      await api("/api/auth/set-password",{method:"POST",body:JSON.stringify({username,password})});
      await login(username,password);
    }catch(e){$("authError").textContent=e.message}
  };
}

async function login(username,password){
  const result=await api("/api/auth/login",{method:"POST",body:JSON.stringify({username,password})});
  if(result.passwordSetupRequired){showPasswordSetup(result.username);return false;}
  if(!result.authenticated)throw new Error("Kunde inte logga in.");
  $("authScreen").classList.add("hidden");
  $("appShell").classList.remove("hidden");
  await loadConfig();
  await loadTickets();
  startAuthTimer();
  return true;
}
async function checkAuth(){
  const result=await api("/api/auth/status");
  if(result.authenticated){
    await loadConfig();
    $("authScreen").classList.add("hidden");
    $("appShell").classList.remove("hidden");
    return true;
  }
  showAuthScreen(!!result.setup);
  return false;
}
function startAuthTimer(){
  if(authTimer)clearInterval(authTimer);
  authTimer=setInterval(async()=>{
    try{
      const result=await api("/api/auth/status");
      if(!result.authenticated){
        clearInterval(authTimer);authTimer=null;showAuthScreen(false,"Din inloggning har gått ut efter 15 minuter utan aktivitet.");
      }
    }catch(e){}
  },60000);
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function showMessage(s){$("message").textContent=s;$("message").classList.remove("hidden");setTimeout(()=>$("message").classList.add("hidden"),3500)}
function filtersFromConfig(){
  const f = state.config.filters;
  $("newR").checked = f.new; 
  $("prio1R").checked = f.prio1; 
  $("prio2R").checked = f.prio2; 
  $("prio3R").checked = f.prio3;
  $("solvedR").checked = f.solved; 
  $("notSolvedR").checked = f.notSolved; 
  $("noOwnerR").checked = f.noOwner; 
  $("allR").checked = f.showAll;

  // Lägg till denna rad så att pausedR läss in korrekt från config:
  if (f.paused !== undefined) { $("pausedR").checked = f.paused; }
}
async function loadConfig(){state.config=await api("/api/config");$("currentUser").textContent=`User: ${state.config.user||"..."}`;$("adminUsersBtn").classList.toggle("hidden",!state.config.isAdmin);filtersFromConfig()}
async function loadTickets(){
  const data = await api("/api/tickets");
  state.tickets = Array.isArray(data) ? data : (data ? [data] : []);
  render();
}
function selectedTicket(){return state.tickets.find(t=>t.id===state.selected)}
function render(){

  const pausedCount = state.tickets.filter(t => t.folder === "paused").length;
  const q = $("search").value.toLowerCase();
  const rows = $("ticketRows");
  rows.innerHTML = "";
  
  const includePaused = $("pausedR")?.checked;

  const showNew = $("newR")?.checked;
  const showPrio1 = $("prio1R")?.checked;
  const showPrio2 = $("prio2R")?.checked;
  const showPrio3 = $("prio3R")?.checked;
  const showSolved = $("solvedR")?.checked;
  const showNotSolved = $("notSolvedR")?.checked;
  const showAll = $("allR")?.checked;
  const showNoOwner = $("noOwnerR")?.checked;

  state.tickets.filter(t => {
    // Ignorera om objektet är null/tomt eller saknar ID
    if (!t || !t.id) return false;

    const folder = t.folder || "";

    // 1. Hantera pausade ärenden
    if (folder === "paused" && !includePaused) return false;
    if (folder === "new" && !showNew) return false;
    if (folder === "prio1" && !showPrio1) return false;
    if (folder === "prio2" && !showPrio2) return false;
    if (folder === "prio3" && !showPrio3) return false;
    if (folder === "solved" && !showSolved) return false;
    if (folder === "notsolved" && !showNotSolved) return false;

    // 3. Ägare och tilldelning
    if (showNoOwner && folder.startsWith("prio") && t.AssignedTo) return false;
    if (!showAll && folder.startsWith("prio") && !showNoOwner && state.config.user && t.AssignedTo !== state.config.user) return false;

    // 4. Sökfilter
    if (q && !JSON.stringify(t).toLowerCase().includes(q)) return false;

    return true;
  }).forEach(t => {
    const tr = document.createElement("tr");
    tr.dataset.id = t.id;
    if (t.id === state.selected) tr.classList.add("selected");
    const deadlineClass = getDeadlineClass(t.Deadline);
    if (deadlineClass) tr.classList.add(deadlineClass);
    
    tr.innerHTML = `<td>${esc(t.Priority)}</td><td>${esc(t.AssignedTo)}</td><td title="${esc(t.ticketName)}">${esc(t.ticketName)}</td>
      <td title="${esc(t.Status)}">${esc(t.Status)}</td><td>${deadlineCell(t.Deadline)}</td><td>${esc(t.ReportedBy)}</td>
      <td>${esc(t.Date)}</td><td>${esc(t.Visible)}</td><td>${esc(t.Recurrent)}</td>`;
    
    tr.onclick = () => { state.selected = t.id; render(); };
    tr.ondblclick = () => openTicket(t.id);
    rows.appendChild(tr);
  });
}
function parseDeadline(v){
  if(!v)return NaN;
  // Ticket deadlines are stored as YYYY-MM-DD HH:mm. Treat them as local time.
  const normalized=String(v).trim().replace(' ','T');
  return new Date(normalized).getTime();
}
function getDeadlineClass(v){
  const timestamp=parseDeadline(v);
  if(isNaN(timestamp))return "";

  const days=(timestamp-Date.now())/86400000;
  const first=Number(state.config?.first);
  const second=Number(state.config?.second);
  const third=Number(state.config?.third);
  if(!Number.isFinite(first)||!Number.isFinite(second)||!Number.isFinite(third))return "";

  // Settings are thresholds in days remaining:
  // above First = no colour, First..Second = blue, Second..Third = yellow, Third or less = red.
  if(days<=third)return "deadline-third";
  if(days<=second)return "deadline-second";
  if(days<=first)return "deadline-first";
  return "";
}
function deadlineCell(v){
  if(!v)return `<span class="deadline-none">—</span>`;
  return `<span>${esc(v)}</span>`;
}
function openModal(html){$("modalCard").innerHTML=html;$("modal").classList.remove("hidden")}
function closeModal(){$("modal").classList.add("hidden");$("modalCard").classList.remove("schedule-wide");$("modalCard").innerHTML=""}
$("modal").onclick=e=>{if(e.target===$("modal"))closeModal()};

function deadlineInputValue(value){
  if(!value) return "";
  const s=String(value).trim();
  const m=s.match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}):(\d{2})/);
  if(m) return `${m[1]}T${m[2]}:${m[3]}`;
  const d=new Date(s);
  if(isNaN(d)) return "";
  const pad=n=>String(n).padStart(2,"0");
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function deadlineSaveValue(value){
  if(!value) return "";
  return value.replace("T"," ");
}

async function openTicket(id){
  try{
    const r=await api("/api/ticket",{method:"POST",body:JSON.stringify({id})});
    const t=r.data;
    openModal(`<div class="ticket-title">${esc(t.Title)}</div>
      <p class="muted">Priority: ${esc(t.Prio)} · Status: ${esc(t.Status)} · Assigned: ${esc(t.ticketOwner)}</p>
      <div class="form-grid">
        <div class="field full"><label>Description</label><textarea id="editError">${esc(t.Error)}</textarea></div>
        <div class="field"><label>Status</label><input id="editStatus" value="${esc(t.Status)}"></div>
        <div class="field">
          <label>Deadline</label>
          <div class="deadline-editor">
            <input id="editDeadline" type="datetime-local" value="${esc(deadlineInputValue(t.deadLine))}">
            <button type="button" id="clearDeadline">Rensa</button>
          </div>
          <small class="muted">Lämna tomt om ticketen inte ska ha någon deadline.</small>
        </div>
        <div class="field"><label>Visibility</label><select id="editVisible"><option ${t.visible==="Private"?"selected":""}>Private</option><option ${t.visible==="Public"?"selected":""}>Public</option></select></div>
        <div class="field"><label>Tag</label><input value="${esc(t.Tag)}" readonly onclick="navigator.clipboard?.writeText(this.value);showMessage('Tag copied')"></div>
        <div class="field full"><label>Updates</label><textarea id="editUpdate">${esc(t.Update)}</textarea></div>
      </div>
      <div class="modal-actions">
        <button class="save" id="saveTicket">Save</button><button id="commentTicket">Add comment</button>
        <button id="solveTicket">Solved</button>
        <button id="notSolveTicket">Not solved</button><button onclick="closeModal()">Close</button>
      </div>`);
    $("clearDeadline").onclick=()=>{$("editDeadline").value="";};
    $("saveTicket").onclick=()=>saveTicket(id);
    $("commentTicket").onclick=()=>commentTicket(id);
    $("solveTicket").onclick=()=>solveWithComment(id,"solved");
    $("notSolveTicket").onclick=()=>solveWithComment(id,"notsolved");
  }catch(e){showMessage(e.message)}
}
async function saveTicket(id){
  await doAction(id,"save",{
    Error:$("editError").value,
    Status:$("editStatus").value,
    deadLine:deadlineSaveValue($("editDeadline").value),
    visible:$("editVisible").value,
    Update:$("editUpdate").value
  });
}
async function commentTicket(id){
  openModal(`<h2>Add a comment</h2><div class="field"><textarea id="commentText">Update, ${new Date().toLocaleDateString("sv-SE")}\n</textarea></div>
  <div class="modal-actions"><button class="save" id="addComment">Add comment</button><button onclick="closeModal()">Close</button></div>`);
  $("addComment").onclick=()=>doAction(id,"comment",{comment:$("commentText").value});
}
async function solveWithComment(id,action){
  const status=prompt("Status:",action==="solved"?"Resolved":"Not solved");
  if(status===null)return;
  await doAction(id,action,{status,update:""});
}
async function doAction(id,action,extra={}){
  try{await api("/api/ticket/action",{method:"POST",body:JSON.stringify({id,action,...extra})});closeModal();await loadTickets();showMessage("Saved")}
  catch(e){showMessage(e.message)}
}
async function actionSelected(action,extra={}){
  if(!state.selected){showMessage("Select a ticket first.");return}
  await doAction(state.selected,action,extra)
}
$("refreshBtn").onclick=()=>loadTickets();
async function logoutAndShowLogin(message="Du är utloggad."){
  if(authTimer){clearInterval(authTimer);authTimer=null;}
  try{await api("/api/auth/logout",{method:"POST",body:"{}"})}catch(e){}
  state.config=null;
  state.tickets=[];
  state.selected=null;
  showAuthScreen(false,message);
}
$("logoutBtn").onclick=()=>logoutAndShowLogin("Du är utloggad.");
$("search").oninput=render;$("clearSearch").onclick=()=>{$("search").value="";render()};
$("solvedR").onchange=reloadWithSettings;$("notSolvedR").onchange=reloadWithSettings;
$("newR").onchange=reloadWithSettings;$("prio1R").onchange=reloadWithSettings;$("prio2R").onchange=reloadWithSettings;$("prio3R").onchange=reloadWithSettings;
$("allR").onchange=reloadWithSettings;$("noOwnerR").onchange=render;
$("pausedR").onchange = reloadWithSettings;
async function reloadWithSettings(){await saveFilterSettings();await loadConfig();await loadTickets()}
async function saveFilterSettings(){
 await api("/api/settings",{method:"POST",body:JSON.stringify({
  NewR:$("newR").checked,
  Prio1R:$("prio1R").checked,
  Prio2R:$("prio2R").checked,
  Prio3R:$("prio3R").checked,
  SolvedR:$("solvedR").checked,
  NotSolvedR:$("notSolvedR").checked,
  PausedR:$("pausedR").checked,
  ShowAllTickets:$("allR").checked,
  ShowWithNoOwners:$("noOwnerR").checked})});
}
$("newBtn").onclick=()=>newTicketModal();
$("renameBtn").onclick=async()=>{if(!state.selected)return showMessage("Select a ticket first.");const n=prompt("New name:",selectedTicket()?.ticketName||"");if(n)await actionSelected("rename",{name:n})};
$("assignBtn").onclick = async () => {
  if (!state.selected) return showMessage("Select a ticket first.");
  
  if (state.config.chooseTicketOwner && Array.isArray(state.config.owners) && state.config.owners.length > 0) {
    const options = state.config.owners.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join("");
    openModal(`
      <h2>Assign Ticket</h2>
      <div class="form-grid">
        <div class="field full">
          <label>Välj användare</label>
          <select id="selectedOwner">${options}</select>
        </div>
      </div>
      <div class="modal-actions">
        <button class="save" id="confirmAssign">Välj</button>
        <button onclick="closeModal()">Avbryt</button>
      </div>
    `);
    $("confirmAssign").onclick = async () => {
      const owner = $("selectedOwner").value;
      closeModal();
      await actionSelected("assign", { owner });
    };
  } else {
    let owner = state.config.user;
    if (state.config.chooseTicketOwner) {
      owner = prompt("Assign to:", state.config.owners ? state.config.owners.join(", ") : "");
    }
    if (owner !== null) await actionSelected("assign", { owner });
  }
};
$("resetAssignBtn").onclick=()=>actionSelected("resetassign");
$("prio1Btn").onclick=()=>actionSelected("prio1");$("prio2Btn").onclick=()=>actionSelected("prio2");$("prio3Btn").onclick=()=>actionSelected("prio3");
$("pauseBtn").onclick=()=>actionSelected("paused");$("deleteBtn").onclick=()=>{if(confirm("Delete selected ticket?"))actionSelected("delete")};
document.onclick = (e) => {
  // Om man klickar utanför en tabellrad (TR) OCH utanför sidofältet/knapparna
  if (!e.target.closest("tr") && !e.target.closest(".sidebar") && !e.target.closest("header")) {
    state.selected = null;
    render();
  }
};


function scheduleLocalDate(value){
  if(!value) return null;
  const s=String(value).trim();
  // Date input values (YYYY-MM-DD) must be interpreted as a local calendar
  // date. JavaScript otherwise interprets them as UTC, which in Sweden can
  // make a ticket created for today appear to belong to yesterday.
  const m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(m){
    const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]));
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const d=new Date(s.replace(" ","T"));
  return Number.isNaN(d.getTime()) ? null : d;
}

function scheduleDateText(v){
  if(!v) return "";
  const s=String(v).trim();
  const d=scheduleLocalDate(s);
  if(!d) return s;
  const parts=new Intl.DateTimeFormat("en-GB",{day:"2-digit",month:"long",year:"numeric"}).formatToParts(d);
  const day=parts.find(p=>p.type==="day")?.value||"";
  const month=parts.find(p=>p.type==="month")?.value||"";
  const year=parts.find(p=>p.type==="year")?.value||"";
  return `${day}-${month}-${year}`;
}

function scheduleIsRelevant(t){
  if(t.Enabled===false) return false;
  if(!t.CreateDate) return true;
  const d=scheduleLocalDate(t.CreateDate);
  if(!d) return true;
  const today=new Date();
  today.setHours(0,0,0,0);
  d.setHours(0,0,0,0);
  return d >= today;
}

async function openScheduleTickets(){
  try{
    const data=await api("/api/schedule-tickets");
    const schedules=Array.isArray(data)?data:(data&&typeof data==="object"&&data.id?[data]:[]);
    openModal(`<div class="schedule-header">
      <h2>List over schedule tickets</h2>
      <div class="schedule-toolbar">
        <button class="schedule-clear" id="scheduleClear">Clear</button>
        <select id="scheduleOwnerFilter"><option value="">All</option></select>
        <button class="schedule-filter" id="scheduleFilter">Filter</button>
        <label class="schedule-relevant"><input type="checkbox" id="scheduleRelevant" checked> Show only relevant schedule tickets</label>
      </div>
    </div>
    <div class="schedule-table-wrap">
      <table class="schedule-table">
        <thead><tr>
          <th>CreateDate</th><th>Assigned to</th><th>Ticket Name</th><th>Status</th><th>Deadline</th>
        </tr></thead>
        <tbody id="scheduleRows"></tbody>
      </table>
    </div>
    <div class="schedule-actions">
      <button id="scheduleOk">OK</button>
      <button class="save" id="newScheduleBtn">New Schedule Ticket</button>
      <button id="importScheduleBtn">Import tickets</button>
      <button class="danger" id="deleteScheduleBtn">Delete ticket</button>
      <input id="scheduleImportFile" type="file" accept=".json,.csv" hidden>
    </div>`);
    $("modalCard").classList.add("schedule-wide");

    const owners=[...new Set(schedules.map(t=>t.AssignedTo).filter(Boolean))].sort();
    $("scheduleOwnerFilter").innerHTML='<option value="">All</option>'+owners.map(o=>`<option value="${esc(o)}">${esc(o)}</option>`).join("");

    let selectedId=null;
    const renderScheduleRows=()=>{
      const owner=$("scheduleOwnerFilter").value;
      const relevant=$("scheduleRelevant").checked;
      const rows=$("scheduleRows");
      rows.innerHTML="";
      schedules.filter(t=>{
        if(relevant && !scheduleIsRelevant(t)) return false;
        if(owner && t.AssignedTo!==owner) return false;
        return true;
      }).forEach(t=>{
        const tr=document.createElement("tr");
        tr.dataset.id=t.id;
        if(t.id===selectedId) tr.classList.add("selected");
        tr.innerHTML=`<td>${esc(scheduleDateText(t.CreateDate))}</td>
          <td>${esc(t.AssignedTo)}</td>
          <td title="${esc(t.ticketName)}">${esc(t.ticketName)}</td>
          <td>${esc(t.Status)}</td>
          <td>${esc(scheduleDateText(t.Deadline))}</td>`;
        tr.onclick=()=>{selectedId=t.id;renderScheduleRows()};
        tr.ondblclick=()=>openScheduleEditor(t);
        rows.appendChild(tr);
      });
    };
    $("scheduleClear").onclick=()=>{
      $("scheduleOwnerFilter").value="";
      $("scheduleRelevant").checked=true;
      renderScheduleRows();
    };
    $("scheduleFilter").onclick=renderScheduleRows;
    $("scheduleRelevant").onchange=renderScheduleRows;
    $("scheduleOk").onclick=()=>closeModal();
    $("newScheduleBtn").onclick=()=>newScheduleTicketModal();
    $("deleteScheduleBtn").onclick=async()=>{
      if(!selectedId){showMessage("Select a schedule ticket first.");return;}
      const item=schedules.find(t=>t.id===selectedId);
      if(!item)return;
      if(!confirm(`Delete schedule ticket "${item.ticketName}"?`))return;
      try{
        await api("/api/schedule-tickets/delete",{method:"POST",body:JSON.stringify({id:selectedId})});
        closeModal();
        showMessage("Schedule ticket deleted");
      }catch(e){showMessage(e.message)}
    };
    $("importScheduleBtn").onclick=()=>$("scheduleImportFile").click();
    $("scheduleImportFile").onchange=()=>showMessage("Import av schedule tickets kan läggas till när formatet från den gamla autoTickets-importen är fastställt.");
    renderScheduleRows();
  }catch(e){showMessage(e.message)}
}

function openScheduleEditor(t){
  const isEdit=!!t;
  // The schedule list uses a full-width card with no padding.
  // Remove that class before opening the editor so the form gets the
  // normal modal padding and the text/fields do not touch the corners.
  $("modalCard").classList.remove("schedule-wide");
  openModal(`<h2>Schedule Ticket</h2>
    <div class="form-grid">
      <div class="field full"><label>Ticket Name</label><input id="scheduleName" value="${esc(t?.ticketName||"")}"></div>
      <div class="field"><label>Create date</label><input id="scheduleCreateDate" type="date" value="${esc((t?.CreateDate||"").slice(0,10))}"></div>
      <div class="field"><label>Assigned to</label><select id="scheduleAssigned"></select></div>
      <div class="field"><label>Status</label><input id="scheduleStatus" value="${esc(t?.Status||"Scheduled")}"></div>
      <div class="field"><label>Deadline</label><input id="scheduleDeadline" type="date" value="${esc((t?.Deadline||"").slice(0,10))}"></div>
      <div class="field"><label>Prio</label><select id="schedulePriority">
        <option value="Prio 1">Prio1</option>
        <option value="Prio 2">Prio2</option>
        <option value="Prio 3">Prio3</option>
      </select></div>
    </div>
    <div class="modal-actions">
      <button class="save" id="saveSchedule">Save</button>
      <button onclick="closeModal()">Close</button>
    </div>`);
  // Assigned to hämtas från owners.json via /api/config.
  const owners=Array.isArray(state.config?.owners)?state.config.owners.filter(Boolean):[];
  const currentOwner=t?.AssignedTo||"";
  const defaultOwner=currentOwner || (owners.includes(state.config?.user)?state.config.user:(owners[0]||""));
  const ownerOptions=owners.slice();
  if(currentOwner && !ownerOptions.includes(currentOwner)) ownerOptions.push(currentOwner);
  $("scheduleAssigned").innerHTML=ownerOptions.length
    ? ownerOptions.map(o=>`<option value="${esc(o)}">${esc(o)}</option>`).join("")
    : '<option value="">Inga användare hittades</option>';
  $("scheduleAssigned").value=defaultOwner;
  $("schedulePriority").value=t?.Priority||"Prio 3";

  $("saveSchedule").onclick=async()=>{
    try{
      if(!$("scheduleAssigned").value){showMessage("Assigned to måste väljas.");return;}
      await api(isEdit?"/api/schedule-tickets/save":"/api/schedule-tickets/new",{method:"POST",body:JSON.stringify({
        ...(isEdit?{id:t.id}:{}),
        ticketName:$("scheduleName").value,
        createDate:$("scheduleCreateDate").value,
        assignedTo:$("scheduleAssigned").value,
        status:$("scheduleStatus").value,
        deadline:$("scheduleDeadline").value,
        priority:$("schedulePriority").value,
        recurrent:true,
        enabled:true
      })});
      closeModal();
      await openScheduleTickets();
      showMessage("Schedule ticket saved");
    }catch(e){showMessage(e.message)}
  };
}

function newScheduleTicketModal(){ openScheduleEditor(null); }

function newTicketModal(){
 openModal(`<h2>📝 Create New Ticket</h2><div class="form-grid">
 <div class="field full"><label>Issue</label><input id="newTitle"></div>
 <div class="field"><label>Priority</label><select id="newPrio"><option>Non</option><option>Prio 1</option><option>Prio 2</option><option>Prio 3</option></select></div>
 <div class="field"><label>Name</label><input id="newName" value=""></div>
 <div class="field full"><label>Description</label><textarea id="newDesc"></textarea></div>
 </div><div class="modal-actions"><button class="save" id="createTicket">New ticket</button><button onclick="closeModal()">Close</button></div>`);
 $("createTicket").onclick=async()=>{try{await api("/api/tickets/new",{method:"POST",body:JSON.stringify({title:$("newTitle").value,priority:$("newPrio").value,name:$("newName").value,description:$("newDesc").value})});closeModal();await loadTickets();showMessage("Ticket created")}catch(e){showMessage(e.message)}};
}
async function openAdminUsers(){
  if(!state.config?.isAdmin){showMessage("Admin access required.");return;}
  try{
    const usersResult=await api("/api/admin/users");
    const users=Array.isArray(usersResult) ? usersResult : (Array.isArray(usersResult.users) ? usersResult.users : []);
    const rows=users.map(u=>`<tr><td>${esc(u.username)}</td><td>${u.admin?"Ja":"Nej"}</td><td>${u.hasPassword?"Ja":"Nej"}</td><td><button class="set-user-password" data-user="${esc(u.username)}">Ändra lösenord</button> <button class="delete-user danger" data-user="${esc(u.username)}">Ta bort</button></td></tr>`).join("");
    openModal(`<h2>Användare</h2>
      <table class="user-table"><thead><tr><th>Användare</th><th>Admin</th><th>Lösenord</th><th></th></tr></thead><tbody>${rows}</tbody></table>
      <h3>Ny användare</h3><div class="form-grid">
        <div class="field"><label>Användarnamn</label><input id="newUserName"></div>
        <div class="field"><label>Lösenord (valfritt)</label><input id="newUserPassword" type="password"></div>
        <div class="field checkbox-field"><label for="newUserAdmin">Administratör</label><input id="newUserAdmin" type="checkbox"></div>
      </div>
      <div class="modal-actions"><button class="save" id="addUserBtn">Lägg till användare</button><button onclick="closeModal()">Stäng</button></div>
      <p class="muted">Om lösenord lämnas tomt kan användaren skapa sitt eget lösenord vid första inloggningen.</p>`);
    document.querySelectorAll(".delete-user").forEach(btn=>btn.onclick=async()=>{
      if(!confirm(`Ta bort användaren ${btn.dataset.user}?`))return;
      try{await api("/api/admin/users",{method:"POST",body:JSON.stringify({action:"delete",username:btn.dataset.user})});showMessage("Användaren är borttagen");await openAdminUsers();}catch(e){showMessage(e.message)}
    });
    document.querySelectorAll(".set-user-password").forEach(btn=>btn.onclick=async()=>{
      const password=prompt(`Nytt lösenord för ${btn.dataset.user}:`);
      if(password===null)return;
      try{await api("/api/admin/users",{method:"POST",body:JSON.stringify({action:"setpassword",username:btn.dataset.user,password})});showMessage("Lösenord sparat");await openAdminUsers();}catch(e){showMessage(e.message)}
    });
    $("addUserBtn").onclick=async()=>{
      try{
        const result=await api("/api/admin/users",{method:"POST",body:JSON.stringify({action:"add",username:$("newUserName").value.trim(),password:$("newUserPassword").value,admin:$("newUserAdmin").checked})});
        showMessage("Användaren skapades");
        await openAdminUsers();
      }catch(e){showMessage(e.message)}
    };
  }catch(e){showMessage(e.message)}
}

$("settingsBtn").onclick = () => {
 const c = state.config;
 openModal(`<h2>Settings</h2><div class="form-grid">
 <div class="field"><label>Inloggad användare</label><input value="${esc(c.user)}" readonly></div>
 <div class="field"><label>Ticket path</label><input id="setPath" value="${esc(c.ticketPath)}"></div>
 <div class="field"><label>Deadline first (days)</label><input id="setFirst" type="number" min="0" step="1" value="${c.first}"></div>
 <div class="field"><label>Deadline second (days)</label><input id="setSecond" type="number" min="0" step="1" value="${c.second}"></div>
 <div class="field"><label>Deadline third (days)</label><input id="setThird" type="number" min="0" step="1" value="${c.third}"></div>
 <div class="field"><label>Auto move</label><input id="setAuto" type="checkbox" ${c.autoMove?"checked":""}></div>
 <div class="field"><label>Choose owner when assigning</label><input id="setChoose" type="checkbox" ${c.chooseTicketOwner?"checked":""}></div>
 </div><p class="muted">Owners: ${esc(c.owners.join(", "))}</p>
 <div class="modal-actions"><button class="save" id="saveSettings">Save</button><button onclick="closeModal()">Close</button></div>`);
 
 $("saveSettings").onclick = async () => {
  try {
   await api("/api/settings", {
    method: "POST",
    body: JSON.stringify({
     TicketPath: $("setPath").value,
     First: +$("setFirst").value,
     Second: +$("setSecond").value,
     Third: +$("setThird").value,
     AutoMove: $("setAuto").checked,
     ChooseTicketOwner: $("setChoose").checked
    })
   });
   closeModal();
   await loadConfig();
   await loadTickets();
   showMessage("Settings saved");
  } catch (e) {
   showMessage(e.message);
  }
 };
};
$("adminUsersBtn").onclick=()=>openAdminUsers();
$("scheduleBtn").onclick=()=>openScheduleTickets();
(async()=>{try{if(await checkAuth()){await loadTickets();startAuthTimer();}}catch(e){showAuthScreen(false,e.message)}})();
