# ReadTickets – webbtjänst

Detta är en webbversion av WPF/PowerShell-programmet `ReadTickets_hkr.ps1`.

## Inloggning

ReadTickets har inloggning. Användarrelaterade filer ligger alltid under:

`%USERPROFILE%\Readtickets`

Där finns bland annat:

- `server.json` – serverinställningar: `Bind`, `Port` och `TicketPath`. Ligger på samma plats som `owners.json`.
- `owners.json` – användare som får logga in. Varje användare har `username`, `password` (PBKDF2-hash) och `admin`. Användarnamnen i denna fil används även som ticketägare.
- `sessions.json` – aktiva inloggningssessioner.
- `config_<användarnamn>.json` – varje användares egna inställningar (filter, deadline-gränser, AutoMove, ChooseTicketOwner m.m.), t.ex. `config_ted.json`.

`Bind` anger vilken adress tjänsten lyssnar på (`0.0.0.0` = alla nätverkskort). Ändringar av `Bind` och `Port` kräver att tjänsten startas om.

Om en gammal gemensam `config.json` finns används den som startvärden när `server.json` och den första användarfilen skapas. Därefter döps den om till `config.json.bak` och kan tas bort.

Ticketdata ligger däremot i den mapp som anges som `TicketPath` i `server.json`.

Första gången tjänsten startas utan några inloggningskonton visas en sida där det första kontot kan skapas. Det kontot blir administratör och sparas i `owners.json`. Om en användare finns i `owners.json` men `password` är tomt kan användaren skapa sitt eget lösenord vid första inloggningen.

Administratörer kan därefter skapa, ta bort och sätta lösenord för användare direkt i ReadTickets under **Användare**. Om lösenord lämnas tomt kan användaren skapa sitt eget lösenord vid första inloggningen.

Inloggning är tidsbegränsad till **15 minuter utan aktivitet**. Varje autentiserad API-användning förlänger sessionen. En bakgrundskontroll i webbläsaren håller inte sessionen vid liv.

## Flytta ticketdata

När `Ticket path` ändras i Settings (endast administratör) flyttas innehållet i den gamla ticketmappen till den nya sökvägen. ReadTickets-mappen under användarprofilen påverkas inte.

`owners.json` räknas som användarrelaterad data och ligger kvar under `%USERPROFILE%\Readtickets`.

## Installation (rekommenderat, HTTPS)

Kör `Install-ReadTicketsWeb.ps1` som administratör (ligger bredvid `ReadTicketsWeb.zip`):

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Install-ReadTicketsWeb.ps1
# Valfritt: -Port 8443 -TicketPath D:\Tickets -DnsName tickets.firma.se -InstallPath "D:\Program\ReadTicketsWeb"
```

Installationen:

- packar upp programmet i `C:\Program Files (x86)\ReadTicketsWeb` (en körande server stoppas först),
- skapar ett självsignerat certifikat (giltigt 5 år) som gäller för datornamn, FQDN, alla IPv4-adresser och eventuella `-DnsName`,
- binder certifikatet till porten (`netsh http add sslcert`) och skapar URL ACL för användaren som kör servern,
- öppnar porten i Windows-brandväggen,
- skriver `server.json` (`Protocol` = `https`, `Port`, `Bind`, `CertificateThumbprint`, `TicketPath`),
- skapar genvägen **ReadTickets Web** i startmenyn.

Servern måste startas av samma Windows-användare som kördes vid installationen, eftersom URL ACL och profilmappen (`%USERPROFILE%\Readtickets`) hör till den användaren.

### Ansluta från andra datorer

Öppna `https://SERVERNAMN:8443`. Eftersom certifikatet är självsignerat visar klienterna en varning tills certifikatet har importerats. Den publika delen exporteras till `www\ReadTicketsWeb.cer` (och kan hämtas från `https://SERVERNAMN:8443/ReadTicketsWeb.cer`). På varje klient, som administratör:

```powershell
Import-Certificate -FilePath .\ReadTicketsWeb.cer -CertStoreLocation Cert:\LocalMachine\Root
```

I en domän kan certifikatet i stället spridas med grupprincip (Trusted Root Certification Authorities). Klienter måste ansluta med ett namn eller en IP-adress som finns i certifikatet. Lägg till fler namn med `-DnsName` och `-NewCertificate` och installera om, och importera därefter den nya `.cer`-filen på klienterna.

Sessionscookien markeras som `Secure` när anslutningen går över HTTPS.

## Start (manuellt)

Kör på Windows-maskinen som har åtkomst till ticket-mappen:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\server.ps1
```

Öppna sedan `http://SERVER-IP:8080` (om `Protocol` är `http`) eller `https://SERVERNAMN:8443` (om `Protocol` är `https`). `Protocol` ställs in i `server.json`.

## Brandvägg

Installationsskriptet skapar regeln automatiskt. Manuellt (byt port vid behov):

```powershell
New-NetFirewallRule -DisplayName "ReadTickets Web HTTPS" -Direction Inbound -Protocol TCP -LocalPort 8443 -Action Allow
```

## Ticketfiler

Ticketfilerna är fortfarande vanliga JSON-filer i samma mappstruktur som tidigare. De behöver därför inte konverteras till en databas.
