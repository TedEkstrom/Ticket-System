# ReadTickets – webbtjänst

Detta är en webbversion av WPF/PowerShell-programmet `ReadTickets_hkr.ps1`.

## Inloggning

ReadTickets har inloggning. Användarrelaterade filer ligger alltid under:

`%USERPROFILE%\Readtickets`

Där finns bland annat:

- `config.json` – användarens ReadTickets-inställningar.
- `owners.json` – användare som får logga in. Varje användare har `username`, `password` (PBKDF2-hash) och `admin`. Användarnamnen i denna fil används även som ticketägare.
- `sessions.json` – aktiva inloggningssessioner.

Ticketdata ligger däremot i den mapp som anges som `TicketPath` i `config.json`.

Första gången tjänsten startas utan några inloggningskonton visas en sida där det första kontot kan skapas. Det kontot blir administratör och sparas i `owners.json`. Om en användare finns i `owners.json` men `password` är tomt kan användaren skapa sitt eget lösenord vid första inloggningen.

Administratörer kan därefter skapa, ta bort och sätta lösenord för användare direkt i ReadTickets under **Användare**. Om lösenord lämnas tomt kan användaren skapa sitt eget lösenord vid första inloggningen.

Inloggning är tidsbegränsad till **15 minuter utan aktivitet**. Varje autentiserad API-användning förlänger sessionen. En bakgrundskontroll i webbläsaren håller inte sessionen vid liv.

## Flytta ticketdata

När `Ticket path` ändras i Settings flyttas innehållet i den gamla ticketmappen till den nya sökvägen. ReadTickets-mappen under användarprofilen påverkas inte.

`owners.json` räknas som användarrelaterad data och ligger kvar under `%USERPROFILE%\Readtickets`.

## Start

Kör på Windows-maskinen som har åtkomst till ticket-mappen:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\server.ps1
```

Öppna sedan:

`http://SERVER-IP:8080`

## Brandvägg

Om klienter på LAN ska kunna ansluta:

```powershell
New-NetFirewallRule -DisplayName "ReadTickets Web" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow
```

## Ticketfiler

Ticketfilerna är fortfarande vanliga JSON-filer i samma mappstruktur som tidigare. De behöver därför inte konverteras till en databas.
