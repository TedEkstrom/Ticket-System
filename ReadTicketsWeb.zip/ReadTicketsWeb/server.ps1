# ReadTickets Web Service
# Windows PowerShell 5.1+
#
# Start:
#   powershell.exe -ExecutionPolicy Bypass -File .\server.ps1
#
# Then open:
#   http://SERVER-IP:8080
#
# The service reads/writes the same JSON ticket folders as the original WPF application.

$ErrorActionPreference = "Stop"
# Bestäm basmappen för tickets och config
$UserDataPath = Join-Path $env:USERPROFILE "Readtickets"
if (-not (Test-Path $UserDataPath)) {
    New-Item -ItemType Directory -Path $UserDataPath -Force | Out-Null
}

$ConfigFile = Join-Path $UserDataPath "config.json"
$OwnersFile = Join-Path $UserDataPath "owners.json"
$SessionFile = Join-Path $UserDataPath "sessions.json"
if (-not (Test-Path $ConfigFile)) {
    @{
        TicketPath = (Join-Path $UserDataPath "tickets")
        Port = 8080
        Bind = "0.0.0.0"
        User = $env:USERNAME
        AutoMove = $true
        First = 8
        Second = 4
        Third = 0
        ChooseTicketOwner = $false
        NewR = $true
        Prio1R = $true
        Prio2R = $true
        Prio3R = $true
        SolvedR = $false
        NotSolvedR = $false
        PausedR = $false
        ShowAllTickets = $true
        ShowWithNoOwners = $false
    } | ConvertTo-Json | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
}

function Load-Config {
    $c = Get-Content -LiteralPath $ConfigFile -Raw -Encoding UTF8 | ConvertFrom-Json
    return $c
}

function Save-Config($c) {
    $c | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
}


function Ensure-OwnersFile {
    if (-not (Test-Path -LiteralPath $OwnersFile)) {
        $legacy = Join-Path $UserDataPath "tickets\owners.json"
        if (Test-Path -LiteralPath $legacy) {
            Copy-Item -LiteralPath $legacy -Destination $OwnersFile -Force
        } else {
            @{ users = @() } | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $OwnersFile -Encoding UTF8
        }
    }
}

function Read-OwnersData {
    Ensure-OwnersFile
    try {
        $v = Get-Content -LiteralPath $OwnersFile -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        throw "owners.json contains invalid JSON."
    }

    # Normalisera owners.json till den nya modellen:
    # {
    #   "users": [
    #     { "username": "User1", "password": "...", "admin": true }
    #   ]
    # }
    $changed = $false
    $users = @()

    if ($null -ne $v.users) {
        $users = @($v.users)
    }

    # Migrera tidigare format med ticketOwners till users.
    if ($users.Count -eq 0 -and $null -ne $v.ticketOwners) {
        $legacyNames = @(([string]$v.ticketOwners -split ",") | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        foreach ($name in $legacyNames) {
            $users += [pscustomobject]@{ username=$name; password=""; admin=$false }
        }
        $changed = $true
    }

    # Migrera passwordHash -> password.
    foreach ($u in $users) {
        if ($u.PSObject.Properties.Name -contains 'passwordHash') {
            $password = [string]$u.passwordHash
            $u | Add-Member -NotePropertyName password -NotePropertyValue $password -Force
            $u.PSObject.Properties.Remove('passwordHash')
            $changed = $true
        }
        if (-not ($u.PSObject.Properties.Name -contains 'password')) {
            $u | Add-Member -NotePropertyName password -NotePropertyValue "" -Force
            $changed = $true
        }
        if (-not ($u.PSObject.Properties.Name -contains 'admin')) {
            $u | Add-Member -NotePropertyName admin -NotePropertyValue $false -Force
            $changed = $true
        }
    }

    # Om ingen administratör finns blir den första användaren administratör.
    if ($users.Count -gt 0 -and @($users | Where-Object { [bool]$_.admin }).Count -eq 0) {
        $users[0].admin = $true
        $changed = $true
    }

    if (-not ($v.PSObject.Properties.Name -contains 'users')) {
        $v | Add-Member -NotePropertyName users -NotePropertyValue $users -Force
        $changed = $true
    } else {
        $v.users = $users
    }
    if ($v.PSObject.Properties.Name -contains 'ticketOwners') {
        $v.PSObject.Properties.Remove('ticketOwners')
        $changed = $true
    }

    if ($changed) { Save-OwnersData $v }
    return $v
}

function Save-OwnersData($data) {
    $data | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $OwnersFile -Encoding UTF8
}

function New-PasswordHash($password) {
    if ([string]::IsNullOrWhiteSpace([string]$password)) { throw "Password is required." }
    $salt = New-Object byte[] 16
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($salt)
    $iterations = 120000
    try {
        $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes(
            $password, $salt, $iterations, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
    } catch {
        $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iterations)
    }
    try {
        $hash = $derive.GetBytes(32)
    } finally {
        $derive.Dispose()
    }
    return "PBKDF2-SHA256`$$iterations`$" + [Convert]::ToBase64String($salt) + "`$" + [Convert]::ToBase64String($hash)
}

function Test-PasswordHash($password,$stored) {
    try {
        $parts = [string]$stored -split '\$'
        if ($parts.Count -ne 4 -or $parts[0] -ne 'PBKDF2-SHA256') { return $false }
        $iterations = [int]$parts[1]
        $salt = [Convert]::FromBase64String($parts[2])
        $expected = [Convert]::FromBase64String($parts[3])
        try {
            $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes(
                $password, $salt, $iterations, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
        } catch {
            $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($password, $salt, $iterations)
        }
        try { $actual = $derive.GetBytes($expected.Length) } finally { $derive.Dispose() }
        if ($actual.Length -ne $expected.Length) { return $false }
        $diff = 0
        for ($i=0; $i -lt $expected.Length; $i++) { $diff = $diff -bor ($actual[$i] -bxor $expected[$i]) }
        return ($diff -eq 0)
    } catch { return $false }
}

function Get-LoginUsers {
    $o = Read-OwnersData
    return @($o.users)
}

function Get-LoginUser($username) {
    return @(Get-LoginUsers | Where-Object { [string]$_.username -eq [string]$username }) | Select-Object -First 1
}

function New-SetupCode {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
    $bytes = New-Object byte[] 12
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $result = ''
    foreach ($b in $bytes) { $result += $chars[$b % $chars.Length] }
    return $result
}

function Test-IsAdmin($session) {
    if ($null -eq $session) { return $false }
    $u = Get-LoginUser ([string]$session.username)
    return ($null -ne $u -and [bool]$u.admin)
}

function Require-Admin($session) {
    if (-not (Test-IsAdmin $session)) { throw [System.UnauthorizedAccessException]::new('Admin access required.') }
    return $session
}

function New-SessionToken {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    return [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
}

function Hash-Token($token) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($token)))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Read-Sessions {
    if (-not (Test-Path -LiteralPath $SessionFile)) { return @() }
    try { return @((Get-Content -LiteralPath $SessionFile -Raw -Encoding UTF8 | ConvertFrom-Json)) } catch { return @() }
}

function Save-Sessions($sessions) {
    @($sessions) | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $SessionFile -Encoding UTF8
}

function Get-SessionFromRequest($req,$touch=$true) {
    $cookie = $req.Cookies['ReadTicketsSession']
    if ($null -eq $cookie -or [string]::IsNullOrWhiteSpace($cookie.Value)) { return $null }
    $tokenHash = Hash-Token $cookie.Value
    $now = [DateTime]::UtcNow
    $sessions = Read-Sessions
    $changed = $false
    $valid = @()
    $found = $null
    foreach ($session in $sessions) {
        try { $last = [DateTime]::Parse([string]$session.lastActivityUtc).ToUniversalTime() } catch { $last = $now.AddMinutes(-16) }
        if (($now - $last).TotalMinutes -ge 15) { $changed = $true; continue }
        $valid += $session
        if ([string]$session.tokenHash -eq $tokenHash) { $found = $session }
    }
    if ($changed) { Save-Sessions $valid }
    if ($null -eq $found) { return $null }
    if ($touch) {
        $found.lastActivityUtc = $now.ToString('o')
        Save-Sessions $valid
    }
    return $found
}

function Require-Auth($req) {
    $session = Get-SessionFromRequest $req
    if ($null -eq $session) { throw [System.UnauthorizedAccessException]::new('Not authenticated.') }
    return $session
}

function Set-SessionCookie($ctx,$token) {
    $cookie = New-Object System.Net.Cookie('ReadTicketsSession',$token,'/')
    $cookie.HttpOnly = $true
    $cookie.Expires = [DateTime]::Now.AddDays(7)
    $ctx.Response.Cookies.Add($cookie)
}

function Clear-SessionCookie($ctx) {
    $cookie = New-Object System.Net.Cookie('ReadTicketsSession','', '/')
    $cookie.HttpOnly = $true
    $cookie.Expires = [DateTime]::Now.AddDays(-1)
    $ctx.Response.Cookies.Add($cookie)
}

function Login-User($username,$password) {
    $username = [string]$username
    $user = Get-LoginUser $username
    if ($null -eq $user) { throw "Fel användarnamn eller lösenord." }
    if ([string]::IsNullOrWhiteSpace([string]$user.password)) {
        return [pscustomobject]@{ PasswordSetupRequired = $true; Username = $username }
    }
    if (-not (Test-PasswordHash $password ([string]$user.password))) { throw "Fel användarnamn eller lösenord." }
    return [pscustomobject]@{ PasswordSetupRequired = $false; Username = $username }
}

function Ensure-Folders {
    $c = Load-Config
    if ([string]::IsNullOrWhiteSpace($c.TicketPath)) { throw "TicketPath is empty." }
    foreach ($n in @("new","solved","notsolved","Deleted","prio1","prio2","prio3","paused", "autoTickets")) {
        $p = Join-Path $c.TicketPath $n
        if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
    }
    Ensure-OwnersFile
}

function Get-Owners {
    $v = Read-OwnersData
    return @($v.users | ForEach-Object { [string]$_.username } | Where-Object { $_ } | Sort-Object -Unique)
}


function Get-ScheduleTickets {
    $c = Load-Config
    Ensure-Folders
    $dir = Join-Path $c.TicketPath "autoTickets"
    if (-not (Test-Path -LiteralPath $dir)) { return @() }

    $items = @()
    Get-ChildItem -LiteralPath $dir -File -Filter "*.json" | ForEach-Object {
        $json = Safe-Json $_.FullName
        if ($null -eq $json) { return }

        $owner = [string]$json.ticketOwner
        if ([string]::IsNullOrWhiteSpace($owner)) { $owner = [string]$json.AssignedTo }
        $title = [string]$json.Title
        if ([string]::IsNullOrWhiteSpace($title)) { $title = [string]$json.ticketName }
        if ([string]::IsNullOrWhiteSpace($title)) { $title = $_.BaseName }

        $createDate = [string]$json.CreateDate
        if ([string]::IsNullOrWhiteSpace($createDate)) { $createDate = [string]$json.createDate }
        if ([string]::IsNullOrWhiteSpace($createDate)) { $createDate = [string]$json.Date }

        $deadline = [string]$json.deadLine
        if ([string]::IsNullOrWhiteSpace($deadline)) { $deadline = [string]$json.Deadline }

        $status = [string]$json.Status
        if ([string]::IsNullOrWhiteSpace($status)) { $status = "Scheduled" }

        $active = $true
        if ($json.PSObject.Properties.Name -contains "Enabled") { $active = [bool]$json.Enabled }
        elseif ($json.PSObject.Properties.Name -contains "enabled") { $active = [bool]$json.enabled }
        elseif ($json.PSObject.Properties.Name -contains "Active") { $active = [bool]$json.Active }
        elseif ($json.PSObject.Properties.Name -contains "active") { $active = [bool]$json.active }

        $items += [pscustomobject]@{
            id = Encode-Id "autoTickets" $_.Name
            file = $_.Name
            ticketName = $title
            CreateDate = $createDate
            AssignedTo = $owner
            Status = $status
            Priority = [string]$(if ($json.Prio) { $json.Prio } elseif ($json.Priority) { $json.Priority } else { "" })
            Deadline = $deadline
            Enabled = $active
            Recurrent = $true
        }
    }

    return @($items | Sort-Object @{Expression={
        try { [datetime]$_.CreateDate } catch { [datetime]::MaxValue }
    }}, ticketName)
}

function New-ScheduleTicket($body) {
    $c = Load-Config
    Ensure-Folders

    $title = ([string]$body.ticketName).Replace(":","-").Trim()
    if ([string]::IsNullOrWhiteSpace($title)) { throw "Ticket Name is required." }

    $dir = Join-Path $c.TicketPath "autoTickets"
    $safeName = ($title -replace '[\\/:*?"<>|]', '-').Trim()
    if ([string]::IsNullOrWhiteSpace($safeName)) { throw "Ticket Name is invalid." }

    $file = Join-Path $dir "$safeName.json"
    if (Test-Path -LiteralPath $file) {
        $file = Join-Path $dir ("{0}_{1}.json" -f $safeName,(Get-Date -Format "yyyyMMddHHmmss"))
    }

    $item = [ordered]@{
        ID = "$(New-Guid)"
        Title = $title
        ticketOwner = [string]$body.assignedTo
        Status = [string]$body.status
        CreateDate = [string]$body.createDate
        deadLine = [string]$body.deadline
        Recurrent = $true
        Prio = [string]$body.priority
        Enabled = $true
        Error = [string]$body.description
    }

    $item | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $file -Encoding UTF8
    return @{ ok=$true; id=(Encode-Id "autoTickets" ([IO.Path]::GetFileName($file))) }
}


function Save-ScheduleTicket($body) {
    $x = Decode-Id ([string]$body.id)
    if ([string]$x.folder -ne "autoTickets") { throw "Invalid schedule ticket." }

    $root = Get-RootPath
    $path = Join-Path (Join-Path $root "autoTickets") $x.file
    if (-not (Test-Path -LiteralPath $path)) { throw "Schedule ticket not found." }

    $data = Safe-Json $path
    if ($null -eq $data) { $data = [pscustomobject]@{} }

    $data.Title = [string]$body.ticketName
    $data.ticketOwner = [string]$body.assignedTo
    $data.Status = [string]$body.status
    $data.CreateDate = [string]$body.createDate
    $data.deadLine = [string]$body.deadline
    $data.Recurrent = $true
    $data.Prio = [string]$body.priority
    if ($data.PSObject.Properties.Name -contains "Enabled") {
        $data.Enabled = [bool]$body.enabled
    } else {
        Add-Member -InputObject $data -MemberType NoteProperty -Name Enabled -Value ([bool]$body.enabled)
    }

    $data | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $path -Encoding UTF8
    return @{ ok=$true }
}

function Delete-ScheduleTicket($id) {
    $x = Decode-Id $id
    if ([string]$x.folder -ne "autoTickets") { throw "Invalid schedule ticket." }

    $root = Get-RootPath
    $path = Join-Path (Join-Path $root "autoTickets") $x.file
    if (-not (Test-Path -LiteralPath $path)) { throw "Schedule ticket not found." }

    Remove-Item -LiteralPath $path -Force
    return @{ ok=$true }
}

function Folder-ForName($name) {
    switch ($name.ToLowerInvariant()) {
        "new"       { return "new" }
        "solved"    { return "solved" }
        "notsolved" { return "notsolved" }
        "deleted"   { return "Deleted" }
        "prio1"     { return "prio1" }
        "prio2"     { return "prio2" }
        "prio3"     { return "prio3" }
        "paused"    { return "paused" }
        "autotickets"{ return "autoTickets" }
        default { throw "Invalid ticket folder." }
    }
}

function Get-RootPath {
    $c = Load-Config
    Ensure-Folders
    return $c.TicketPath
}

function Encode-Id($folder,$file) {
    $raw = @{ folder=$folder; file=$file } | ConvertTo-Json -Compress
    return [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($raw)).TrimEnd("=").Replace("+","-").Replace("/","_")
}

function Decode-Id($id) {
    $s = $id.Replace("-","+").Replace("_","/")
    switch ($s.Length % 4) { 2 { $s += "==" } 3 { $s += "=" } }
    return ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($s)) | ConvertFrom-Json)
}

function Safe-Json($path) {
    try {
        return (Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json)
    } catch {
        return $null
    }
}

function Read-Tickets($currentUser) {
    $c = Load-Config
    if ([string]::IsNullOrWhiteSpace([string]$currentUser)) { $currentUser = [string]$c.User }
    Ensure-Folders
    $folders = @()
    if ([bool]$c.NewR) { $folders += "new" }
    if ([bool]$c.Prio1R) { $folders += "prio1" }
    if ([bool]$c.Prio2R) { $folders += "prio2" }
    if ([bool]$c.Prio3R) { $folders += "prio3" }
    if ([bool]$c.SolvedR) { $folders += "solved" }
    if ([bool]$c.PausedR) { $folders += "paused" }
    if ([bool]$c.NotSolvedR) { $folders += "notsolved" }
    $items = @()

    foreach ($folder in $folders) {
        $dir = Join-Path $c.TicketPath $folder
        if (-not (Test-Path $dir)) { continue }

        Get-ChildItem -LiteralPath $dir -File -Filter "*.json" | ForEach-Object {
            $json = Safe-Json $_.FullName
            if ($null -eq $json) { return }

            $owner = [string]$json.ticketOwner
            $include = $true

            if ($folder -in @("prio1","prio2","prio3")) {
                if ($c.ShowAllTickets) {
                    $include = $true
                } elseif ($c.ShowWithNoOwners) {
                    $include = [string]::IsNullOrWhiteSpace($owner)
                } else {
                    $include = ($owner -eq [string]$currentUser)
                }
            }

            if ($include) {
                $status = [string]$json.Status
                if ($folder -eq "new") { $status = "New" }
                $items += [pscustomobject]@{
                    id = Encode-Id $folder $_.Name
                    folder = $folder
                    file = $_.Name
                    ticketName = $_.BaseName
                    Title = [string]$json.Title
                    Priority = [string]$json.Prio
                    Status = $status
                    ReportedBy = [string]$json.Username
                    Name = [string]$json.Name
                    Date = [string]$json.Date
                    AssignedTo = $owner
                    Deadline = [string]$json.deadLine
                    Visible = [string]$json.visible
                    Recurrent = $(if (($json.PSObject.Properties.Name -contains "Recurrent") -and ([string]$json.Recurrent -eq "True" -or [string]$json.Recurrent -eq "true")) { "X" } else { "" })
                    Tag = [string]$json.Tag
                }
            }
        }
    }
    return @($items)
}

function Read-TicketById($id) {
    $x = Decode-Id $id
    $folder = Folder-ForName $x.folder
    $root = Get-RootPath
    $path = Join-Path (Join-Path $root $folder) $x.file
    if (-not (Test-Path -LiteralPath $path)) { throw "Ticket not found." }
    return [pscustomobject]@{
        id = $id
        folder = $folder
        file = $x.file
        data = Safe-Json $path
    }
}

function Write-TicketById($id,$data) {
    $x = Decode-Id $id
    $folder = Folder-ForName $x.folder
    $root = Get-RootPath
    $path = Join-Path (Join-Path $root $folder) $x.file
    if (-not (Test-Path -LiteralPath $path)) { throw "Ticket not found." }
    $data | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $path -Encoding UTF8
}

function Move-Ticket($id,$destination,$timestampName=$false) {
    $x = Decode-Id $id
    $srcFolder = Folder-ForName $x.folder
    $dstFolder = Folder-ForName $destination
    $root = Get-RootPath
    $src = Join-Path (Join-Path $root $srcFolder) $x.file
    if (-not (Test-Path -LiteralPath $src)) { throw "Ticket not found." }

    $name = $x.file
    if ($timestampName) {
        $base = [IO.Path]::GetFileNameWithoutExtension($name).Replace(" ","")
        $name = "${base}_$(Get-Date -Format 'yyyyMMdd_ss').json"
    }
    $dst = Join-Path (Join-Path $root $dstFolder) $name
    Move-Item -LiteralPath $src -Destination $dst -Force
}

function New-Ticket($body,$currentUser) {
    $c = Load-Config
    if ([string]::IsNullOrWhiteSpace([string]$currentUser)) { $currentUser = [string]$c.User }
    Ensure-Folders
    $title = ([string]$body.title).Replace(":","-").Trim()
    if ([string]::IsNullOrWhiteSpace($title)) { throw "Title is required." }
    if ([string]::IsNullOrWhiteSpace([string]$body.description)) { throw "Description is required." }
    if ([string]::IsNullOrWhiteSpace([string]$body.name)) { throw "Name is required." }

    $item = [ordered]@{
        Title=$title
        Computer=""
        Tag=$env:COMPUTERNAME
        Date=(Get-Date -Format "yyMMdd")
        Error=[string]$body.description
        Name=[string]$body.name
        Update=""
        Username=[string]$currentUser
        Prio=[string]$body.priority
        Status=""
        ticketOwner=""
        visible="Private"
        id="$(New-Guid)"
    }
    $folder = switch ([string]$body.priority) {
        "Prio 1" {"prio1"}
        "Prio 2" {"prio2"}
        "Prio 3" {"prio3"}
        default {"new"}
    }
    $file = Join-Path (Join-Path $c.TicketPath $folder) "$title.json"
    $item | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $file -Encoding UTF8
    return $item
}


function Move-TicketRootContents($source,$destination) {
    $source = [IO.Path]::GetFullPath($source)
    $destination = [IO.Path]::GetFullPath($destination)
    if ($source.TrimEnd('\') -eq $destination.TrimEnd('\')) { return }
    if (-not (Test-Path -LiteralPath $source)) { return }
    if (-not (Test-Path -LiteralPath $destination)) { New-Item -ItemType Directory -Path $destination -Force | Out-Null }

    $sourceItems = @(Get-ChildItem -LiteralPath $source -Force | Where-Object { $_.Name -ne "owners.json" })
    foreach ($item in $sourceItems) {
        $target = Join-Path $destination $item.Name
        if (Test-Path -LiteralPath $target) {
            throw "Cannot move ticket data because the destination already contains '$($item.Name)'."
        }
    }
    foreach ($item in $sourceItems) {
        Move-Item -LiteralPath $item.FullName -Destination $destination -Force
    }
}

function Handle-Api($method,$path,$body) {
    Ensure-Folders
    $session = $null
    if ($path -notmatch '^/api/auth/(status|login|setup|set-password)$') { $session = Require-Auth $global:CurrentRequest }
    switch -Regex ($path) {
        '^/api/auth/status$' {
            $session = Get-SessionFromRequest $global:CurrentRequest $false
            if ($null -eq $session) { return @{ authenticated=$false; setup=((Get-LoginUsers).Count -eq 0) } }
            return @{ authenticated=$true; username=[string]$session.username; expiresIdleMinutes=15 }
        }
        '^/api/auth/login$' {
            $login = Login-User ([string]$body.username) ([string]$body.password)
            if ($login.PasswordSetupRequired) {
                return @{ authenticated=$false; passwordSetupRequired=$true; username=[string]$login.Username }
            }
            $username = [string]$login.Username
            $token = New-SessionToken
            $sessions = @(Read-Sessions | Where-Object { [string]$_.username -ne $username })
            $sessions += [pscustomobject]@{ tokenHash=(Hash-Token $token); username=$username; createdUtc=[DateTime]::UtcNow.ToString('o'); lastActivityUtc=[DateTime]::UtcNow.ToString('o') }
            Save-Sessions $sessions
            Set-SessionCookie $global:CurrentContext $token
            return @{ authenticated=$true; username=$username; expiresIdleMinutes=15 }
        }
        '^/api/auth/logout$' {
            $cookie = $global:CurrentRequest.Cookies['ReadTicketsSession']
            if ($cookie) {
                $hash = Hash-Token $cookie.Value
                Save-Sessions @(Read-Sessions | Where-Object { [string]$_.tokenHash -ne $hash })
            }
            Clear-SessionCookie $global:CurrentContext
            return @{ ok=$true }
        }
        '^/api/auth/setup$' {
            if ((Get-LoginUsers).Count -gt 0) { throw "Initial setup is already completed." }
            $username = [string]$body.username
            $password = [string]$body.password
            if ([string]::IsNullOrWhiteSpace($username)) { throw "Username is required." }
            if ($password.Length -lt 8) { throw "Password must be at least 8 characters." }
            $o = Read-OwnersData
            $o.users = @([pscustomobject]@{ username=$username; password=(New-PasswordHash $password); admin=$true })
            Save-OwnersData $o
            return @{ ok=$true }
        }
        '^/api/auth/set-password$' {
            $username = [string]$body.username
            $password = [string]$body.password
            if ($password.Length -lt 8) { throw "Password must be at least 8 characters." }
            $user = Get-LoginUser $username
            if ($null -eq $user) { throw "Användaren finns inte." }
            if (-not [string]::IsNullOrWhiteSpace([string]$user.password)) { throw "Användaren har redan ett lösenord." }
            $o = Read-OwnersData
            foreach ($u in @($o.users)) {
                if ([string]$u.username -eq $username) {
                    $u.password = New-PasswordHash $password
                    if ($u.PSObject.Properties.Name -contains 'passwordSetupTokenHash') { $u.PSObject.Properties.Remove('passwordSetupTokenHash') }
                    if ($u.PSObject.Properties.Name -contains 'passwordSetupExpiresUtc') { $u.PSObject.Properties.Remove('passwordSetupExpiresUtc') }
                }
            }
            Save-OwnersData $o
            return @{ ok=$true }
        }
        '^/api/admin/users$' {
            Require-Admin $session | Out-Null
            if ($method -eq 'GET') {
                return @{ users = @(Get-LoginUsers | ForEach-Object { @{ username=[string]$_.username; admin=[bool]$_.admin; hasPassword=(-not [string]::IsNullOrWhiteSpace([string]$_.password)) } }) }
            }
            $action = [string]$body.action
            $username = [string]$body.username
            $o = Read-OwnersData
            $users = @($o.users)
            $user = @($users | Where-Object { [string]$_.username -eq $username }) | Select-Object -First 1
            switch ($action) {
                'add' {
                    if ([string]::IsNullOrWhiteSpace($username)) { throw 'Username is required.' }
                    if ($null -ne $user) { throw 'Användaren finns redan.' }
                    $newUser = [pscustomobject]@{ username=$username; password=""; admin=[bool]$body.admin }
                    $password = [string]$body.password
                    if (-not [string]::IsNullOrWhiteSpace($password)) {
                        if ($password.Length -lt 8) { throw 'Password must be at least 8 characters.' }
                        $newUser.password = New-PasswordHash $password
                    }
                    $o.users = @($users + $newUser)
                    Save-OwnersData $o
                    return @{ok=$true; setupCode=$null}
                }
                'setpassword' {
                    if ($null -eq $user) { throw 'Användaren finns inte.' }
                    $password=[string]$body.password
                    if ($password.Length -lt 8) { throw 'Password must be at least 8 characters.' }
                    foreach ($u in $users) { if ([string]$u.username -eq $username) { $u.password=New-PasswordHash $password; $u.PSObject.Properties.Remove('passwordSetupTokenHash'); $u.PSObject.Properties.Remove('passwordSetupExpiresUtc') } }
                    $o.users=$users; Save-OwnersData $o
                    return @{ok=$true}
                }
                'delete' {
                    if ($null -eq $user) { throw 'Användaren finns inte.' }
                    if ($username -eq [string]$session.username) { throw 'Du kan inte ta bort den användare du själv är inloggad som.' }
                    if ([bool]$user.admin -and @($users | Where-Object { [bool]$_.admin }).Count -le 1) { throw 'Det måste finnas minst en administratör.' }
                    $o.users=@($users | Where-Object { [string]$_.username -ne $username }); Save-OwnersData $o
                    return @{ok=$true}
                }
                default { throw 'Unknown admin user action.' }
            }
        }
        '^/api/config$' {
            $session = Require-Auth $global:CurrentRequest

            $c=Load-Config
            return @{
                ticketPath=$c.TicketPath
                user=$(if($session){[string]$session.username}else{[string]$c.User})
                autoMove=[bool]$c.AutoMove
                first=[int]$c.First
                second=[int]$c.Second
                third=[int]$c.Third
                chooseTicketOwner=[bool]$c.ChooseTicketOwner
                filters=@{
    new=[bool]$c.NewR; prio1=[bool]$c.Prio1R; prio2=[bool]$c.Prio2R; prio3=[bool]$c.Prio3R
    solved=[bool]$c.SolvedR; notSolved=[bool]$c.NotSolvedR; paused=[bool]$c.PausedR
    showAll=[bool]$c.ShowAllTickets; noOwner=[bool]$c.ShowWithNoOwners
}
                owners=@(Get-Owners)
                isAdmin=(Test-IsAdmin $session)
            }
        }
        '^/api/schedule-tickets$' {
            return ,@(Get-ScheduleTickets)
        }
        '^/api/schedule-tickets/new$' {
            return New-ScheduleTicket $body
        }
        '^/api/schedule-tickets/save$' {
            return Save-ScheduleTicket $body
        }
        '^/api/schedule-tickets/delete$' {
            return Delete-ScheduleTicket ([string]$body.id)
        }
        '^/api/tickets$' {
            return @(Read-Tickets ([string]$session.username))
        }
        '^/api/ticket$' {
            if ($method -eq "GET" -or $method -eq "POST") { return Read-TicketById ([string]$body.id) }
            throw "Unsupported method."
        }
        '^/api/tickets/new$' {
            return New-Ticket $body ([string]$session.username)
        }
        '^/api/ticket/action$' {
            $id=[string]$body.id
            $action=[string]$body.action
            $t=Read-TicketById $id
            $data=$t.data

            switch ($action) {
                "save" {
                    foreach($p in @("Error","Status","deadLine","visible","Update")) {
                        if ($body.PSObject.Properties.Name -contains $p) { $data.$p=$body.$p }
                    }
                    Write-TicketById $id $data
                }
                "solved" {
                    if ($body.update) { $data.Update=[string]$body.update }
                    $data.Status=[string]$body.status
                    Write-TicketById $id $data
                    Move-Ticket $id "solved" $true
                }
                "notsolved" {
                    if ($body.update) { $data.Update=[string]$body.update }
                    $data.Status=[string]$body.status
                    Write-TicketById $id $data
                    Move-Ticket $id "notsolved" $true
                }
                "prio1" { $data.Prio="Prio 1"; Write-TicketById $id $data; Move-Ticket $id "prio1" $false }
                "prio2" { $data.Prio="Prio 2"; Write-TicketById $id $data; Move-Ticket $id "prio2" $false }
                "prio3" { $data.Prio="Prio 3"; Write-TicketById $id $data; Move-Ticket $id "prio3" $false }
                "paused" { Move-Ticket $id "paused" $false }
                "delete" { Move-Ticket $id "Deleted" $true }
                "assign" {
                    $owner = if ($body.owner) { [string]$body.owner } else { [string]$session.username }
                    $data.ticketOwner = $owner
                    Write-TicketById $id $data
                }
                "resetassign" { $data.ticketOwner=""; Write-TicketById $id $data }
                "comment" {
                    $comment=[string]$body.comment
                    $line="Update, $(Get-Date -Format 'dd MMM yyyy')`r`n$comment`r`n--------------------------------------------------------------------"
                    if ([string]::IsNullOrWhiteSpace([string]$data.Update)) { $data.Update=$line } else { $data.Update="$($data.Update)`r`n$line" }
                    Write-TicketById $id $data
                }
                "togglevisible" {
                    $data.visible = if ([string]$data.visible -eq "Public") {"Private"} else {"Public"}
                    Write-TicketById $id $data
                }
                "rename" {
                    $new=[string]$body.name
                    if ([string]::IsNullOrWhiteSpace($new)) { throw "Name cannot be empty." }
                    $x=Decode-Id $id
                    $root=Get-RootPath
                    $old=Join-Path (Join-Path $root (Folder-ForName $x.folder)) $x.file
                    $newPath=Join-Path (Join-Path $root (Folder-ForName $x.folder)) (($new.Replace(":","-")) + ".json")
                    if (Test-Path $newPath) { throw "A ticket with that name already exists." }
                    Rename-Item -LiteralPath $old -NewName ([IO.Path]::GetFileName($newPath))
                }
                default { throw "Unknown action: $action" }
            }
            return @{ ok=$true }
        }
        '^/api/settings$' {
            $c=Load-Config
            $oldTicketPath = [string]$c.TicketPath
            $newTicketPath = $oldTicketPath
            if ($body.PSObject.Properties.Name -contains "TicketPath") { $newTicketPath = [string]$body.TicketPath }
            if ([string]::IsNullOrWhiteSpace($newTicketPath)) { throw "TicketPath is empty." }
            if ([IO.Path]::GetFullPath($oldTicketPath).TrimEnd('\') -ne [IO.Path]::GetFullPath($newTicketPath).TrimEnd('\')) {
                Move-TicketRootContents $oldTicketPath $newTicketPath
            }
            foreach($p in @("TicketPath","AutoMove","First","Second","Third","ChooseTicketOwner","NewR","Prio1R","Prio2R","Prio3R","SolvedR","NotSolvedR","PausedR","ShowAllTickets","ShowWithNoOwners")) {
                if ($body.PSObject.Properties.Name -contains $p) { $c.$p=$body.$p }
            }
            $c.TicketPath = $newTicketPath
            Save-Config $c
            Ensure-Folders
            return Handle-Api "GET" "/api/config" $null
        }
        default { throw "API endpoint not found." }
    }
}

function Send-Response($ctx,$status,$content,$contentType="application/json; charset=utf-8") {
    if ($null -eq $content) { $content = "{}" }
    $bytes=[Text.Encoding]::UTF8.GetBytes($content)
    $ctx.Response.StatusCode=$status
    $ctx.Response.ContentType=$contentType
    $ctx.Response.ContentLength64=$bytes.Length
    $ctx.Response.Headers.Add("Cache-Control","no-store")
    $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Get-Static($relative) {
    if ([string]::IsNullOrWhiteSpace($relative) -or $relative -eq "/") { $relative="/index.html" }
    $relative=$relative.TrimStart("/").Replace("/","\")
    if ($relative.Contains("..")) { throw "Invalid path." }
    $file=Join-Path (Join-Path $PSScriptRoot "www") $relative
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { return $null }
    return $file
}

Ensure-Folders
$c=Load-Config
$prefix="http://*:$( $c.Port )/"
$listener=New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
$listener.Start()
Write-Host "ReadTickets Web running at $prefix" -ForegroundColor Green
Write-Host "Ticket path: $($c.TicketPath)"
Write-Host "Press Ctrl+C to stop."

while ($listener.IsListening) {
    try {
        $ctx=$listener.GetContext()
        try {
            $req=$ctx.Request
            $path=$req.Url.AbsolutePath
            $global:CurrentRequest = $req
            $global:CurrentContext = $ctx
            if ($path.StartsWith("/api/")) {
                $body=$null
                if ($req.HasEntityBody) {
                    $reader=New-Object IO.StreamReader($req.InputStream,$req.ContentEncoding)
                    $bodyText=$reader.ReadToEnd()
                    if ($bodyText) { $body=$bodyText | ConvertFrom-Json }
                }
                if ($req.HttpMethod -eq "GET" -and $path -eq "/api/ticket") {
                    $result=Handle-Api "GET" $path $body
                } else {
                    $result=Handle-Api $req.HttpMethod $path $body
                }
                Send-Response $ctx 200 ($result | ConvertTo-Json -Depth 30)
            } else {
                $file=Get-Static $path
                if ($null -eq $file) { Send-Response $ctx 404 '{"error":"Not found"}'; continue }
                $ext=[IO.Path]::GetExtension($file).ToLowerInvariant()
                $ct=@{".html"="text/html; charset=utf-8";".js"="text/javascript; charset=utf-8";".css"="text/css; charset=utf-8";".json"="application/json"}[$ext]
                if (-not $ct) { $ct="application/octet-stream" }
                $bytes=[IO.File]::ReadAllBytes($file)
                $ctx.Response.StatusCode=200
                $ctx.Response.ContentType=$ct
                $ctx.Response.ContentLength64=$bytes.Length
                $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
                $ctx.Response.OutputStream.Close()
            }
        } catch {
         $isUnauthorized = $_.Exception -is [System.UnauthorizedAccessException]
         if ($isUnauthorized) {
             try { Send-Response $ctx 401 '{"error":"Not authenticated."}' } catch {}
         } else {
             Write-Host "FEL I SERVER: $($_.Exception.Message)" -ForegroundColor Red
             Write-Host $_.ScriptStackTrace -ForegroundColor DarkRed
             $msg=($_.Exception.Message -replace '"','\"')
             try { Send-Response $ctx 500 ('{"error":"'+$msg+'"}') } catch {}
         }
     }
    } catch {
        if ($listener.IsListening) { Write-Warning $_.Exception.Message }
    }
}
